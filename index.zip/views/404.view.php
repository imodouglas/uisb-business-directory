<div class="full-screen flex-box p20">
    <div align="center">
        <div> <h3> Ouch! This page does not exist. </h3> </div>
        <div> <p> I think you missed your way. </p> </div>
    </div>
</div>